function enterStore() {
  alert("Redirecting to the full MediSmoke shop...");
  window.location.href = "https://www.amazon.co.uk/s?k=cannabis+accessories";
}
